#include <iostream>
#include <string>

int main(){

    std::string a;

    std::cout << "Enter your name: ";

    std::cin >> a;

    std::cout << "Hello " << a << std::endl;

    return 0;
}