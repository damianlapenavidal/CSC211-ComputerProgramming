#include <iostream>
#include <iomanip>

int main() {
    int a, b, c;

    std::cin >> a;
    std::cin >> b;

    c = a - b;

    std::cout << a << " - " << b << " = " << c << std::endl;

    return 0;
}