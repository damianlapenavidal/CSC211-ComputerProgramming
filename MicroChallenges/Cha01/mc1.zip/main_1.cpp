#include <iostream>
#include <iomanip>

int main() {
    std::cout << "Hello World!";
}